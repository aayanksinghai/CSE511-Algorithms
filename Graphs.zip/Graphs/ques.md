Solve the following problems

https://leetcode.com/problems/detonate-the-maximum-bombs/description/?envType=problem-list-v2&envId=depth-first-search

https://leetcode.com/problems/count-nodes-equal-to-average-of-subtree/description/?envType=problem-list-v2&envId=depth-first-search

https://leetcode.com/problems/house-robber-iii/description/?envType=problem-list-v2&envId=depth-first-search

https://leetcode.com/problems/water-and-jug-problem/description/?envType=problem-list-v2&envId=depth-first-search

https://leetcode.com/problems/loud-and-rich/description/?envType=problem-list-v2&envId=depth-first-search

https://leetcode.com/problems/keys-and-rooms/description/?envType=problem-list-v2&envId=depth-first-search

https://leetcode.com/problems/is-graph-bipartite/description/?envType=problem-list-v2&envId=depth-first-search

https://leetcode.com/problems/employee-importance/?envType=problem-list-v2&envId=breadth-first-search

https://leetcode.com/problems/employee-importance/?envType=problem-list-v2&envId=breadth-first-search

https://leetcode.com/problems/shortest-path-in-binary-matrix/description/?envType=problem-list-v2&envId=breadth-first-search

https://leetcode.com/problems/maximum-width-of-binary-tree/description/?envType=problem-list-v2&envId=breadth-first-search

https://leetcode.com/problems/network-delay-time/description/?envType=problem-list-v2&envId=shortest-path

https://leetcode.com/problems/find-the-city-with-the-smallest-number-of-neighbors-at-a-threshold-distance/description/?envType=problem-list-v2&envId=shortest-path

https://leetcode.com/problems/course-schedule/description/?envType=problem-list-v2&envId=breadth-first-search

https://leetcode.com/problems/path-sum/description/?envType=problem-list-v2&envId=depth-first-search

https://leetcode.com/problems/evaluate-division/description/?envType=problem-list-v2&envId=shortest-path

https://leetcode.com/problems/minimum-cost-to-convert-string-i/description/?envType=problem-list-v2&envId=shortest-path

https://leetcode.com/problems/min-cost-to-connect-all-points/description/?envType=problem-list-v2&envId=minimum-spanning-tree

https://leetcode.com/problems/redundant-connection-ii/description/?envType=problem-list-v2&envId=union-find

https://leetcode.com/problems/bricks-falling-when-hit/description/?envType=problem-list-v2&envId=union-find

https://leetcode.com/problems/similar-string-groups/description/?envType=problem-list-v2&envId=union-find

https://leetcode.com/problems/couples-holding-hands/description/?envType=problem-list-v2&envId=union-find

https://leetcode.com/problems/last-day-where-you-can-still-cross/description/?envType=problem-list-v2&envId=union-find

https://leetcode.com/problems/find-minimum-time-to-reach-last-room-i/description/?envType=problem-list-v2&envId=shortest-path

https://leetcode.com/problems/find-critical-and-pseudo-critical-edges-in-minimum-spanning-tree/description/?envType=problem-list-v2&envId=minimum-spanning-tree

https://leetcode.com/problems/valid-arrangement-of-pairs/description/?envType=problem-list-v2&envId=eulerian-circuit

https://leetcode.com/problems/reconstruct-itinerary/description/?envType=problem-list-v2&envId=eulerian-circuit

https://leetcode.com/problems/minimum-number-of-days-to-disconnect-island/descripAtion/?envType=problem-list-v2&envId=strongly-connected-component
